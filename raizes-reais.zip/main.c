#include <stdio.h>
#include <math.h>

int main()
{
    float a, b, c;
    printf("Digite o coeficiente A: ");
    scanf("%f", &a);
    printf("Digite o coeficiente B: ");
    scanf("%f", &b);
    printf("Digite o coeficiente C: ");
    scanf("%f", &c);
    
    float delta = b*b - 4*a*c;
    
    if( delta >= 0 ){
        float x1 = ( -b + sqrt( delta) ) / (2 * a );
        float x2 = ( -b - sqrt( delta) ) / (2 * a );
        printf("As raízes sao %.3f e %.3f\n", x1, x2);
    }
    else
        printf("Não ha raizes reais!\n");
        
    return 0;
}

